<?php
include 'dbh.php';
if (is_uploaded_file($_FILES['csv_file']['tmp_name'])) {
        echo "<h1>" . "File ". $_FILES['csv_file']['name'] ." uploaded 
 successfully." . "</h1>";
        echo "<h2>Displaying contents:</h2>";
        readfile($_FILES['csv_file']['tmp_name']);
    }
    $handle = fopen($_FILES['csv_file']['tmp_name'], "r");
 while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
    //$table= rtrim($_FILES['csv_file']['name'],".csv");
    $usn=$data[0];
    $uname=$data[1];
    $pass = $usn;                       
    $utype="student";
    $status="yes";
    echo $usn;       
    $sql = "INSERT INTO users(usn,name,pass,utype,status)VALUES('$usn','$uname','$pass','$utype','$status');";

    $inserted = mysqli_query($conn, $sql);
    if($inserted == 1)
    {
       //header("Location:registered_successfull.php");
       
         echo 'successfull';
         print "<script type='text/javascript'>alert('Successfully Added Student');window.location='add_student.php';</script>";
    }
    else
    {

        echo 'unsuccessfull';
    }
}
?>

