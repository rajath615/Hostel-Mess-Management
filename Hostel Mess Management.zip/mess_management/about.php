<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
         <title>VKIT Hostel Mess</title>
    </head>
    <body>
        <?php
        include 'index.html';
        ?>
        
        <br>
         <br>
         <br>
          <!-- About Section -->
  <section class="page-section bg-primary text-white mb-0" id="about">
    <div class="container">

      <!-- About Section Heading -->
      <h2 class="page-section-heading text-center text-uppercase text-white">About</h2>

      <!-- Icon Divider -->
      <div class="divider-custom divider-light">
        <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
        <div class="divider-custom-line"></div>
      </div>

      <!-- About Section Content -->
      <div class="row">
        <div class="col-lg-4 ml-auto">
          <p class="lead">Well-appointed rooms for single/double occupancy with attached/common baths.Spacious halls for comfortable dining.Breakfast, lunch, evening snacks and special dinner is provided. The Mess Committee made up of student representatives to decide the mess menu.</p>
        </div>
        <div class="col-lg-4 mr-auto">
          <p class="lead">Large recreation halls equipped with T and newspapers.Round the clock security to all blocks. Additional security at blocks occupied by freshers. RO drinking water.Cabled/ Wi-Fi internet provided.</p>
        </div>
      </div>

      

    </div>
  </section>
  <?php
  include 'footer.php';
  ?>
    </body>
</html>
