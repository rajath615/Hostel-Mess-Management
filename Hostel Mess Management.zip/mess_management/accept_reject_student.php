<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
         <title>VKIT Hostel Mess</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        <link href="own.css" rel="stylesheet" type="text/css">
        <style>
        table, th, td {
          border: 1px solid black;
          border-collapse: collapse;
        }
        th, td {
          padding: 5px;
          text-align: left;
        }
        </style>
    </head>
    <body>
        <?php
        include 'after_login_header.php';
        include 'dbh.php';
        $sql="SELECT * FROM users where STATUS='no';";
        $result=mysqli_query($conn, $sql);     
        $count = mysqli_num_rows($result);
        ?>
        <br><br><br><br> <br>
        <div class="around_form" style="margin-bottom: 5%">
            <div class="left_own">
                <h2>Accept And Reject Student</h2>
                <div class="row_1" >
                    <?php 
                        if($count<=0){
                            ?>
                    <h4>No Students</h4>
                    
                    <?php
                        }else{
                    ?>
                    <table style="width:100%">
                        <tr>
                            <th>
                                USN
                            </th>
                            <th>
                                Name
                            </th>
                            <th>
                                Room No.
                            </th>
                            <th>
                                Year
                            </th>
                            <th>
                                Accept/Reject
                            </th>
                        </tr>
                        <?php
                                while ($row = mysqli_fetch_array($result)) { 
                                    $usn=$row["usn"];
                        ?>
                            <tr>
                                <td>
                                    <?php
                                    echo $row["usn"];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    echo $row["NAME"];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    echo $row["room_no"];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    echo $row["YEAR"];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    echo "<a href='accept_student.php?usn=$usn'>"
                                    ."Accept</a>/<a href='reject_student.php?usn=$usn'>"
                                    ."Reject</a>";
                                    ?>
                                </td>
                            </tr>
                        <?php            
                                }
                        ?>
                        
                        
                    </table>
                        <?php
                        
                                }
                    ?>
                </div>
            </div>
        </div>
        
        <br><br><br><br> <br><br><br><br><br>
        
        <?php
        include 'footer.php';
        ?>
    </body>
</html>
