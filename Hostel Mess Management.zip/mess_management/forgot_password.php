<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        
         <title>VKIT Hostel Mess</title>
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">



    <link rel="icon" href="Favicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <script type="text/javascript">
   function check_pwd(){
    var pwd=document.getElementById("password").value;
     var cpwd=document.getElementById("confirm_password").value;
     var year=parseInt(document.getElementById("year").value);   
     var Phone=parseInt(document.getElementById("phone_number").value);
     if(pwd!=cpwd){
         alert("password and confirm passward not match");
         return false;
     }else
     if(Phone.length>10){
         alert("Enter a Valid Phone Number");
         return false;
     } 
 } 
 function isNumberKey(evt){
     
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57))        
        return false;
    }
       
    

    </script>
    </head>
    <body>
           <?php
    include 'index.html';
    ?>
       <br><br><br><br> <br>
        <div class="cotainer">
        <div class="row justify-content-center">
            <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">Forgot Password</div>
                        <div class="card-body">
                            <form onsubmit="return check_pwd()"action="change_pass.php" method="post">
                               <div class="form-group row">
                                    <label for="usn" class="col-md-4 col-form-label text-md-right">USN</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="usn" class="form-control" pattern="[1]{1}[v][k][0-9]{2}[a-zA-Z]{2}[0-9]{3}" title="You must use this Format:1vk16cs002" maxlength="10"name="usn">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="phone_number" class="col-md-4 col-form-label text-md-right">Phone Number</label>
                                    <div class="col-md-6">
                                        <input type="number" required pattern="[1-9]{1}[0-9]{9}"  id="phone_number" class="form-control" name="phoneno" onkeypress="return isNumberKey(event)" minlength="10" maxlength="10">
                                    </div>
                                </div>
                                
                                    <div class="col-md-6 offset-md-4">
                                        <button type="submit" class="btn btn-primary" name="submit" >
                                        Forgot Password
                                        </button>
                                    </div>
                        <br>
                        
                        
                                  
                            
                            <?php
                            
                            
                        
                       
                        ?>
                         </form> 
                            </div>
                            </div>
                             </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
    <br>
        <?php
include 'footer.php';
?>
    </body>
</html>
