<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
         <title>VKIT Hostel Mess</title>
    </head>
    <body>
        <?php
       include 'dbh.php';
       session_start();
       $_SESSION['status']="Active";
            $uname = strtolower($_POST["usn"]);
            $pass = $_POST["pass"];
             //echo "Uname : $uname Pass : $pass<br>";
            $sql = "SELECT * FROM users WHERE usn='$uname' AND pass='$pass';";
                        
              $result=mysqli_query($conn, $sql);
                
            if($row = mysqli_fetch_array($result))
            {
                if(($row['status'])=="no"){
                    $usn=$row['usn'];
                 print "<script type='text/javascript'>alert('$usn not approved by warden ');window.location='login.php';</script>";
                }elseif ((($row['email']==NULL))&&($row['utype']=='student')) {
                         header("Location:add_student_data.php?usn=$uname");
                }else{                
                $_SESSION['name']=$_POST['usn'];
                $utype = $row['utype'];
                $page = $utype."Page.php";
                header("Location:$page");
                }
            }
            else
            {
                print "<script type='text/javascript'>alert('Invalid USN and password ');window.location='login.php';</script>";
            }            
             
        ?>
    </body>
</html>
