<?php
  include 'dbh.php';
  
    $sql1="SELECT usn,NAME,room_no,YEAR,phone,email FROM users where STATUS='yes' and utype='student' ORDER BY usn ASC;";
    $result1=mysqli_query($conn, $sql1); 
    if($result1->num_rows > 0){
    $delimiter = ",";
    $filename = "students_" . date('Y-m-d') . ".csv";
    
    //create a file pointer
    $f = fopen('php://memory', 'w');
    
    //set column headers
    $fields = array('USN', 'Name', 'Room No', 'Year', 'Phone no', 'Email ID');
    fputcsv($f, $fields, $delimiter);
    
    //output each row of the data, format line as csv and write to file pointer
    while($row = $result1->fetch_assoc()){
        $lineData = array($row['usn'], $row['NAME'], $row['room_no'], $row['YEAR'], $row['phone'], $row['email']);
        fputcsv($f, $lineData, $delimiter);
    }
    
    //move back to beginning of file
    fseek($f, 0);
    
    //set headers to download file rather than displayed
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '";');
    
    //output all remaining data on a file pointer
    fpassthru($f);
    
}
exit;

        
            /*$states = "USN Name Room_No. Year Phone_No. Email_ID";
            $statesArray = [];
            $states1 = explode(' ',$states);
            $pdf = new FPDF();
            $pdf->AddPage();
            $pdf->SetFont('Arial','B',12);		
            foreach($states1 as $heading) {
                    if($heading=="Email_ID"){
                    $pdf->Cell(31,10,$heading,1);
                    } else {
                     $pdf->Cell(15,10,$heading,1);

                    }
            }
            foreach($result1 as $row) {
                    $pdf->SetFont('Arial','',12);	
                    $pdf->Ln();
                    foreach($row as $column)
                    $pdf->Cell(31,10,$column,1);
            }
            $pdf->Output();*/
?>
