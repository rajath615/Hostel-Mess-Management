<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
       
         <title>VKIT Hostel Mess</title>
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">



    <link rel="icon" href="Favicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <script type="text/javascript">
   function check_pwd(){
    var pwd=document.getElementById("password").value;
     var cpwd=document.getElementById("confirm_password").value;
     var year=parseInt(document.getElementById("year").value);   
     var Phone=parseInt(document.getElementById("phone_number").value); 
     if(Phone.length<10){
         alert("Enter a Valid Phone Number");
         return false;
     }else
     
     if(pwd!=cpwd){
         alert("password and confirm passward not match");
         return false;
     }else
     if((year>4)||(year<0)){
         alert("Year should be with in 0-4");
         return false;
     }
     
   
 } 
 function isNumberKey(evt){
     
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57))        
        return false;
    }
       
    

    </script>
    </head>
    <body>
        <?php
        include 'index.html';
        ?>
        <br><br><br><br> <br>
        <div class="cotainer">
        <div class="row justify-content-center">
            <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">Sign up</div>
                        <div class="card-body">
                            <form  onsubmit="return check_pwd()" action="signup_validator.php" method="post">
                                <div class="form-group row">
                                    <label for="name" class="col-md-4 col-form-label text-md-right">Name</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="name" class="form-control" name="full-name">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="usn" class="col-md-4 col-form-label text-md-right">USN</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="usn" class="form-control" pattern="[1]{1}[v][k][0-9]{2}[a-zA-Z]{2}[0-9]{3}" title="You must use this Format:1vk16cs002" maxlength="10"name="usn">
                                    </div>
                                </div>
                                
                                <div class="form-group row">
                                    <label for="email_address" class="col-md-4 col-form-label text-md-right">E-Mail Address</label>
                                    <div class="col-md-6">
                                        <input type="email" required id="email_address" class="form-control" name="email-address">
                                    </div>
                                </div>                               

                                <div class="form-group row">
                                    <label for="phone_number" class="col-md-4 col-form-label text-md-right">Phone Number</label>
                                    <div class="col-md-6">
                                        <input type="number" required pattern="[1-9]{1}[0-9]{9}"  id="phone_number" class="form-control" name="phoneno" onkeypress="return isNumberKey(event)" minlength="10" maxlength="10">
                                    </div>
                                </div>

                               

                                <div class="form-group row">
                                    <label for="roon_no" class="col-md-4 col-form-label text-md-right">Room Number</label>
                                    <div class="col-md-6">
                                        <input type="number" required  id="room_no" class="form-control" name="room_no" onkeypress="return isNumberKey(event)" >
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="year" class="col-md-4 col-form-label text-md-right">Year</label>
                                    <div class="col-md-6">
                                        <input type="number" required id="year" placeholder="1/2/3/4"class="form-control" name="year" onkeypress="return isNumberKey(event)" maxlength="1">
                                    </div>
                                </div>
                                 <div class="form-group row">
                                    <label for="password" class="col-md-4 col-form-label text-md-right">Password</label>
                                    <div class="col-md-6">
                                        <input type="password" required id="password" class="form-control" name="pass">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="confirm_password" class="col-md-4 col-form-label text-md-right">Confirm Password</label>
                                    <div class="col-md-6">
                                        <input type="password" required id="confirm_password" class="form-control" name="c_pass">
                                    </div>
                                </div>
                                    <div class="col-md-6 offset-md-4">
                                        <button type="submit" class="btn btn-primary">
                                        Sign Up
                                        </button>
                                    </div>
                               
                               
                            </form>
                            
                             </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
    <br>
<?php
        include 'footer.php';
        ?>
    </body>
</html>
