<?php
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
include 'dbh.php';
$mbf=$_POST["mbf"];
$mlunch=$_POST["mlunch"];
$msnacks=$_POST["msnacks"];
$mdinner=$_POST["mdinner"];
$tbf=$_POST["tbf"];
$tlunch=$_POST["tlunch"];
$tsnacks=$_POST["tsnacks"];
$tdinner=$_POST["tdinner"];
$wbf=$_POST["wbf"];
$wlunch=$_POST["wlunch"];
$wsnacks=$_POST["wsnacks"];
$wdinner=$_POST["wdinner"];
$thbf=$_POST["thbf"];
$thlunch=$_POST["thlunch"];
$thsnacks=$_POST["thsnacks"];
$thdinner=$_POST["thdinner"];
$fbf=$_POST["fbf"];
$flunch=$_POST["flunch"];
$fsnacks=$_POST["fsnacks"];
$fdinner=$_POST["fdinner"];
$sbf=$_POST["sbf"];
$slunch=$_POST["slunch"];
$ssnacks=$_POST["ssnacks"];
$sdinner=$_POST["sdinner"];
$subf=$_POST["subf"];
$sulunch=$_POST["sulunch"];
$susnacks=$_POST["susnacks"];
$sudinner=$_POST["sudinner"];
$sql1 ="UPDATE menu SET bf = '$mbf',lunch = '$mlunch',snacks = '$msnacks',dinner = '$mdinner' WHERE day = 'monday';";
$sql2 ="UPDATE menu SET bf = '$tbf',lunch = '$tlunch',snacks = '$tsnacks',dinner = '$tdinner' WHERE day = 'tuesday';";
$sql3 ="UPDATE menu SET bf = '$wbf',lunch = '$wlunch',snacks = '$wsnacks',dinner = '$wdinner' WHERE day = 'wednesday';";
$sql4 ="UPDATE menu SET bf = '$thbf',lunch = '$thlunch',snacks = '$thsnacks',dinner = '$thdinner' WHERE day = 'thursday';";
$sql5 ="UPDATE menu SET bf = '$fbf',lunch = '$flunch',snacks = '$fsnacks',dinner = '$fdinner' WHERE day = 'friday';";
$sql6 ="UPDATE menu SET bf = '$sbf',lunch = '$slunch',snacks = '$ssnacks',dinner = '$sdinner' WHERE day = 'saturday';";
$sql7 ="UPDATE menu SET bf = '$subf',lunch = '$sulunch',snacks = '$susnacks',dinner = '$sudinner' WHERE day = 'sunday';";
$updated1 = mysqli_query($conn, $sql1);
$updated2 = mysqli_query($conn, $sql2);
$updated3 = mysqli_query($conn, $sql3);
$updated4 = mysqli_query($conn, $sql4);
$updated5 = mysqli_query($conn, $sql5);
$updated6 = mysqli_query($conn, $sql6);
$updated7 = mysqli_query($conn, $sql7);
   





if(($updated1 == 1)&&($updated2 == 1)&&($updated3 == 1)&&($updated4 == 1)&&($updated5 == 1)&&($updated6 == 1)&&($updated7 == 1))
   {
      print "<script type='text/javascript'>alert('Menu Updated');window.location='add_menu.php';</script>";
   }
   else
   {
       header("Location:error_page.php");
   }
?>

