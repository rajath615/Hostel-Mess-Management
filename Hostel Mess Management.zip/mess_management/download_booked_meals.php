<?php


                                if($result->num_rows > 0){
                                $delimiter = ",";
                                $filename = "booking_from_".$from_date."_to_".$to_date.".csv";

                                //create a file pointer
                                $f = fopen('php://memory', 'w');

                                //set column headers
                                $fields = array('bf_no', 'lunch_no', 'snacks_no', 'dinner_no',);
                                fputcsv($f, $fields, $delimiter);

                                //output each row of the data, format line as csv and write to file pointer
                                while($row = $result->fetch_assoc()){
                                    $lineData = array($row['bf_no'], $row['lunch_no'], $row['snacks_no'], $row['dinner_no']);
                                    fputcsv($f, $lineData, $delimiter);
                                }

                                //move back to beginning of file
                                fseek($f, 0);

                                //set headers to download file rather than displayed
                                header('Content-Type: text/csv');
                                header('Content-Disposition: attachment; filename="' . $filename . '";');

                                //output all remaining data on a file pointer
                                fpassthru($f);

                            }
                            exit;
 
 ?>