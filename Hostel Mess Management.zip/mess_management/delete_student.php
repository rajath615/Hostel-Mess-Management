<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
include 'dbh.php';
$usn=$_REQUEST['usn']; 
$sql = "Delete from users WHERE usn='$usn';";
$Deleted = mysqli_query($conn, $sql);
   if($Deleted == 1)
   {
      print "<script type='text/javascript'>alert('$usn Deleted');window.location='view_student.php';</script>";
   }
   else
   {
       header("Location:error_page.php");
   }
?>
