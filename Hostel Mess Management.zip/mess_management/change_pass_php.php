<?php
include 'dbh.php';
 if(isset($_POST["change_password"])){
        $pass = $_POST["pass"];
        $usn1=$_GET["usn"];
        echo $usn1;
        $sql = "UPDATE users SET pass = '$pass' WHERE usn = '$usn1'  ;";
        $inserted = mysqli_query($conn, $sql);
       if($inserted == 1)
      {              
           echo 'successfull';
           print "<script type='text/javascript'>alert('Successfully Changed Password');window.location='login.php';</script>";
      }
      else
      {

          echo 'unsuccessfull';
      }
    }
                        ?>
