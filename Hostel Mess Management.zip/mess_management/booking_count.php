<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
       
         <title>VKIT Hostel Mess</title>
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">



    <link rel="icon" href="Favicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    
    </head>
    <body>
        <?php
        include 'after_login_header.php';
        include 'dbh.php';
        $from_date=$_POST['From'];
        $to_date=$_POST['To'];
        
         $sql="SELECT sum(bf)as bf_no,sum(lunch)as lunch_no,sum(snacks)as snacks_no,sum(dinner)as dinner_no FROM booking where date between '$from_date' and '$to_date';";
    $result=mysqli_query($conn, $sql);
    $row= mysqli_fetch_array($result);
        ?>
        <br><br><br><br> <br>
        <div class="cotainer">
        <div class="row justify-content-center">
            <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">Meals Booked From Date: <?php echo $from_date;?> And To Date: <?php echo $to_date;?></div>
                        <div class="card-body">
                            <h4>Meals Booked</h4>
                            <form  method="post" >
                                <div class="form-group row">
                                    <label for="name" class="col-md-4 col-form-label text-md-right">No. of Breakfast</label>
                                    <div class="col-md-6">
                                        <?php
                                        if($row['bf_no']==NULL){
                                        ?>
                                        <input type="text" class="form-control" readonly value="0">
                                        <?php
                                        } else {?>
                                            <input type="text" class="form-control" readonly value="<?php echo $row['bf_no'];?>">
                                        <?php }
                                        ?>
                                    </div>
                                </div>
                                 <div class="form-group row">
                                    <label for="name" class="col-md-4 col-form-label text-md-right">No. of Lunch</label>
                                    <div class="col-md-6">
                                        <?php
                                        if($row['lunch_no']==NULL){
                                        ?>
                                        <input type="text" class="form-control" readonly value="0">
                                        <?php
                                        } else {?>
                                            <input type="text" class="form-control" readonly value="<?php echo $row['lunch_no'];?>">
                                        <?php }
                                        ?>
                                    </div>
                                </div>
                                
                                 <div class="form-group row">
                                    <label for="name" class="col-md-4 col-form-label text-md-right">No. of Snacks</label>
                                    <div class="col-md-6">
                                        <?php
                                        if($row['snacks_no']==NULL){
                                        ?>
                                        <input type="text" class="form-control" readonly value="0">
                                        <?php
                                        } else {?>
                                            <input type="text" class="form-control" readonly value="<?php echo $row['snacks_no'];?>">
                                        <?php }
                                        ?>
                                    </div>
                                </div>                             

                                 <div class="form-group row">
                                    <label for="name" class="col-md-4 col-form-label text-md-right">No. of Dinner</label>
                                    <div class="col-md-6">
                                        <?php
                                        if($row['dinner_no']==NULL){
                                        ?>
                                        <input type="text" class="form-control" readonly value="0">
                                        <?php
                                        } else {?>
                                            <input type="text" class="form-control" readonly value="<?php echo $row['dinner_no'];?>">
                                        <?php }
                                        ?>
                                    </div>
                                </div> 
                               
                            </form>
                         
                             </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
    <br>
<?php
        include 'footer.php';
        ?>
    </body>
</html>
