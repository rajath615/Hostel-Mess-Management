<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
         <title>VKIT Hostel Mess</title>
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Fonts -->
        <link rel="dns-prefetch" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">
        <link rel="icon" href="Favicon.png">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
        <link href="own.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <?php
    include 'after_login_header.php';
    include 'dbh.php';
    $sql1="select * from menu where day='monday';";
    $sql2="select * from menu where day='tuesday';";
    $sql3="select * from menu where day='wednesday';";
    $sql4="select * from menu where day='thursday';";
    $sql5="select * from menu where day='friday';";
    $sql6="select * from menu where day='saturday';";
    $sql7="select * from menu where day='sunday';";
    $result1=mysqli_query($conn, $sql1);
    $result2=mysqli_query($conn, $sql2);
    $result3=mysqli_query($conn, $sql3);
    $result4=mysqli_query($conn, $sql4);
    $result5=mysqli_query($conn, $sql5);
    $result6=mysqli_query($conn, $sql6);
    $result7=mysqli_query($conn, $sql7);
    $row1= mysqli_fetch_array($result1);
    $row2= mysqli_fetch_array($result2);
    $row3= mysqli_fetch_array($result3);
    $row4= mysqli_fetch_array($result4);
    $row5= mysqli_fetch_array($result5);
    $row6= mysqli_fetch_array($result6);
    $row7= mysqli_fetch_array($result7);
    ?>
       <br><br><br><br><br>
        <div class="cotainer">
        <div class="row justify-content-center">
            <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">ADD Menu</div>
                        <div class="card-body">
                            <form  action="add_menu_php.php" method="post">
                                <div class="left_add">
                                <label>Monday</label>
                                </div>
                                <br>
                                <div class="form-group row">
                                    <label for="mbf" class="col-md-4 col-form-label text-md-right">BreakFast</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="mbf" class="form-control" name="mbf"value="<?php echo $row1['bf'];?>">
                                    </div>
                                </div>
                                 <div class="form-group row">
                                    <label for="mlunch" class="col-md-4 col-form-label text-md-right">Lunch</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="mlunch" class="form-control" name="mlunch"value="<?php echo $row1['lunch'];?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="msnacks" class="col-md-4 col-form-label text-md-right">Snacks</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="msnacks" class="form-control" name="msnacks"value="<?php echo $row1['snacks'];?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="mdinner" class="col-md-4 col-form-label text-md-right">Dinner</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="mdinner" class="form-control" name="mdinner"value="<?php echo $row1['dinner'];?>">
                                    </div>
                                </div>
                                <div class="left_add">
                                <label>Tuesday</label>
                                </div>
                                <br>
                                <div class="form-group row">
                                    <label for="tbf" class="col-md-4 col-form-label text-md-right">BreakFast</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="tbf" class="form-control" name="tbf" value="<?php echo $row2['bf'];?>">
                                    </div>
                                </div>
                                 <div class="form-group row">
                                    <label for="tlunch" class="col-md-4 col-form-label text-md-right">Lunch</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="tlunch" class="form-control" name="tlunch"value="<?php echo $row2['lunch'];?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="tsnacks" class="col-md-4 col-form-label text-md-right">Snacks</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="tsnacks" class="form-control" name="tsnacks"value="<?php echo $row2['snacks'];?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="tdinner" class="col-md-4 col-form-label text-md-right">Dinner</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="tdinner" class="form-control" name="tdinner"value="<?php echo $row2['dinner'];?>">
                                    </div>
                                </div>
                                <div class="left_add">
                                <label>Wednesday</label>
                                </div>
                                <br>
                                <div class="form-group row">
                                    <label for="wbf" class="col-md-4 col-form-label text-md-right">BreakFast</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="wbf" class="form-control" name="wbf"value="<?php echo $row3['bf'];?>">
                                    </div>
                                </div>
                                 <div class="form-group row">
                                    <label for="wlunch" class="col-md-4 col-form-label text-md-right">Lunch</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="wlunch" class="form-control" name="wlunch"value="<?php echo $row3['lunch'];?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="wsnacks" class="col-md-4 col-form-label text-md-right">Snacks</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="wsnacks" class="form-control" name="wsnacks"value="<?php echo $row3['snacks'];?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="wdinner" class="col-md-4 col-form-label text-md-right">Dinner</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="wdinner" class="form-control" name="wdinner"value="<?php echo $row3['dinner'];?>">
                                    </div>
                                </div>
                                <div class="left_add">
                                <label>Thursday</label>
                                </div>
                                <br>
                                <div class="form-group row">
                                    <label for="thbf" class="col-md-4 col-form-label text-md-right">BreakFast</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="thbf" class="form-control" name="thbf"value="<?php echo $row4['bf'];?>">
                                    </div>
                                </div>
                                 <div class="form-group row">
                                    <label for="thlunch" class="col-md-4 col-form-label text-md-right">Lunch</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="thlunch" class="form-control" name="thlunch"value="<?php echo $row4['lunch'];?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="thsnacks" class="col-md-4 col-form-label text-md-right">Snacks</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="thsnacks" class="form-control" name="thsnacks"value="<?php echo $row4['snacks'];?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="thdinner" class="col-md-4 col-form-label text-md-right">Dinner</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="thdinner" class="form-control" name="thdinner"value="<?php echo $row4['dinner'];?>">
                                    </div>
                                </div>
                                <div class="left_add">
                                <label>Friday</label>
                                </div>
                                <br>
                                <div class="form-group row">
                                    <label for="fbf" class="col-md-4 col-form-label text-md-right">BreakFast</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="fbf" class="form-control" name="fbf"value="<?php echo $row5['bf'];?>">
                                    </div>
                                </div>
                                 <div class="form-group row">
                                    <label for="flunch" class="col-md-4 col-form-label text-md-right">Lunch</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="flunch" class="form-control" name="flunch"value="<?php echo $row5['lunch'];?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="fsnacks" class="col-md-4 col-form-label text-md-right">Snacks</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="fsnacks" class="form-control" name="fsnacks"value="<?php echo $row5['snacks'];?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="fdinner" class="col-md-4 col-form-label text-md-right">Dinner</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="fdinner" class="form-control" name="fdinner"value="<?php echo $row5['dinner'];?>">
                                    </div>
                                </div>
                                <div class="left_add">
                                <label>Saturday</label>
                                </div>
                                <br>
                                <div class="form-group row">
                                    <label for="sbf" class="col-md-4 col-form-label text-md-right">BreakFast</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="sbf" class="form-control" name="sbf"value="<?php echo $row6['bf'];?>">
                                    </div>
                                </div>
                                 <div class="form-group row">
                                    <label for="slunch" class="col-md-4 col-form-label text-md-right">Lunch</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="slunch" class="form-control" name="slunch"value="<?php echo $row6['lunch'];?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="ssnacks" class="col-md-4 col-form-label text-md-right">Snacks</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="ssnacks" class="form-control" name="ssnacks"value="<?php echo $row6['snacks'];?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="sdinner" class="col-md-4 col-form-label text-md-right">Dinner</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="sdinner" class="form-control" name="sdinner"value="<?php echo $row6['dinner'];?>">
                                    </div>
                                </div>
                                <div class="left_add">
                                <label>Sunday</label>
                                </div>
                                <br>
                                <div class="form-group row">
                                    <label for="subf" class="col-md-4 col-form-label text-md-right">BreakFast</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="subf" class="form-control" name="subf" value="<?php echo $row7['bf'];?>">
                                    </div>
                                </div>
                                 <div class="form-group row">
                                    <label for="sulunch" class="col-md-4 col-form-label text-md-right">Lunch</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="sulunch" class="form-control" name="sulunch"value="<?php echo $row7['lunch'];?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="susnacks" class="col-md-4 col-form-label text-md-right">Snacks</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="susnacks" class="form-control" name="susnacks"value="<?php echo $row7['snacks'];?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="sudinner" class="col-md-4 col-form-label text-md-right">Dinner</label>
                                    <div class="col-md-6">
                                        <input type="text" required id="sudinner" class="form-control" name="sudinner"value="<?php echo $row7['dinner'];?>">
                                    </div>
                                </div>
                                    <div class="col-md-6 offset-md-4">
                                        <button type="submit" class="btn btn-primary">
                                        Update Menu
                                        </button>
                                    </div>
                        
                                
                            </form>
                            
                            </div>
                             </div>
                        </div>
                    </div>
            </div>
       <br>
        <?php
include 'footer.php';
?>
    </body>
</html>
