<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
         <title>VKIT Hostel Mess</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        <link href="own.css" rel="stylesheet" type="text/css">
         <!-- Custom fonts for this theme -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

  <!-- Theme CSS -->
  <link href="css/freelancer.min.css" rel="stylesheet">
        
    </head>
    <body id="page-top">
        <?php
        include 'after_login_header.php';
        ?>
        <br><br><br><br> <br>  
        
            <div class="left_own">
                <h2>Superuser PAGE</h2>
            </div>
        
        <section class="page-section portfolio" id="portfolio">
        <div class="container">
           <div class="row">

        <!-- Portfolio Item 1 -->
        <div class="col-md-6 col-lg-4">
            <a href="accept_reject_student.php">
          <div class="portfolio-item mx-auto">
            <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">                
              <div class="portfolio-item-caption-content text-center text-white">
                <label>Accept/Reject Student</label>
              </div>
            </div>
            <img class="img-fluid" src="img/acc_rej.png" alt="">
          </div>
                </a>
        </div>
        <!-- Portfolio Item 2 -->
        <div class="col-md-6 col-lg-4">
            <a href="add_menu.php">
          <div class="portfolio-item mx-auto" >
            <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
              <div class="portfolio-item-caption-content text-center text-white">
                <label>Add Menu</label>
              </div>
            </div>
            <img class="img-fluid" src="img/menu2.jpg" alt="">
          </div>
                </a>
        </div>

        <!-- Portfolio Item 3 -->
        <div class="col-md-6 col-lg-4">
            <a href="view_student.php">
          <div class="portfolio-item mx-auto">
            <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
              <div class="portfolio-item-caption-content text-center text-white">
                <label>View Students</label>
              </div>
            </div>
            <img class="img-fluid" src="img/view_stu.png" alt="">
          </div>
            </a>
        </div>
         <div class="col-md-6 col-lg-4">
            <a href="add_student.php">
          <div class="portfolio-item mx-auto">
            <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
              <div class="portfolio-item-caption-content text-center text-white">
                <label>Add Student</label>
              </div>
            </div>
            <img class="img-fluid" src="img/view_stu.png" alt="">
          </div>
            </a>
        </div>
         <!-- Portfolio Item 2 -->
        <div class="col-md-6 col-lg-4">
            <a href="view_menu_download.php">
          <div class="portfolio-item mx-auto" >
            <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
              <div class="portfolio-item-caption-content text-center text-white">
                <label>View Menu</label>
              </div>
            </div>
            <img class="img-fluid" src="img/menu2.jpg" alt="">
          </div>
                </a>
        </div>
        <div class="col-md-6 col-lg-4">
            <a href="From_to_booked.php">
          <div class="portfolio-item mx-auto" >
            <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
              <div class="portfolio-item-caption-content text-center text-white">
                <label>View Booked Meals</label>
              </div>
            </div>
            <img class="img-fluid" src="img/book.jpg" alt="">
          </div>
                </a>
        </div>
       
                </div>
            </div>
        </section>
            </div>
         <?php
        include 'footer.php';
        ?>
    </body>
</html>
