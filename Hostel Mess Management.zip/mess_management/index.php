<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>VKIT HOSTEL MESS</title>
                <link href="own.css" rel="stylesheet" type="text/css">

    </head>
    <body>
        <?php
        include 'index.html';
        // put your code here
        ?>
        
         <!-- Masthead -->
      <div class="container d-flex align-items-center flex-column" >

      <!-- Masthead Avatar Image -->
            <img  width="130%" height="720" src="img/IMG_20191107_132057_1.jpg" alt="" >

            <div class="centered"><h1 style="color:white;" >VKIT HOSTEL MESS</h1></div>

      <!-- Masthead Heading -->
      

     
      

    </div>
  


  <?php
  include 'footer.php';
  ?>
              

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Contact Form JavaScript -->
  <script src="js/jqBootstrapValidation.js"></script>
  <script src="js/contact_me.js"></script>

  <!-- Custom scripts for this template -->
  <script src="js/freelancer.min.js"></script>
    </body>
</html>
