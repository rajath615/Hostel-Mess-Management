<?php
$conn=mysqli_connect("localhost","root","","hostelmess");
if(!$conn) 
{
	die("connection failed".mysql_connect_error());
} 

?>
